//package org.example;
import org.example.TestAutomat;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.stream.Stream;

public class TestingAutomat {

    private static Stream<Arguments> inputProvider() {
        return Stream.of(
                Arguments.of(List.of("A", "TSA", "TSETA"), TestAutomat.State.State0),

                Arguments.of(List.of("T", "TETST", "TESAT", "TEXST"), TestAutomat.State.State1),

                Arguments.of(List.of("TE", "TTTE"), TestAutomat.State.State2),

                Arguments.of(List.of("TES"), TestAutomat.State.State3),

                Arguments.of(List.of("TEST", "TESTING", "TTEST", "123TEST456", "TESTTEST", "TEST123TEST", "cloakAsTesrestfesttest"), TestAutomat.State.F),

                Arguments.of(List.of("TETST", "TESAT"), TestAutomat.State.State1),

                Arguments.of(List.of("TTTE"), TestAutomat.State.State2),

                Arguments.of(List.of("TEXST", "ТeST"), TestAutomat.State.State1),

                Arguments.of(List.of("TETS"), TestAutomat.State.State0),

                Arguments.of(List.of(""), TestAutomat.State.State0),

                Arguments.of(List.of("123TEST456", "cloakAsTesrestfesttest"), TestAutomat.State.F),

                Arguments.of(List.of("te       st", "ТeST"), TestAutomat.State.State1)
        );
    }

    @ParameterizedTest
    @MethodSource("inputProvider")
    void testAutomat(List<String> inputs, TestAutomat.State expectedState) {
        for (String input : inputs) {
            assertEquals(expectedState, TestAutomat.Automat(input));
        }
    }

    @Test
    void testAutomatDefault() {
        assertEquals(TestAutomat.State.F, TestAutomat.Automat("TESTING"));
        assertEquals(TestAutomat.State.F, TestAutomat.Automat("TESTTEST"));
        assertEquals(TestAutomat.State.F, TestAutomat.Automat("TTEST"));
        assertEquals(TestAutomat.State.State0, TestAutomat.Automat("TESA"));
        assertEquals(TestAutomat.State.State1, TestAutomat.Automat("TETST"));
    }
}