package org.example;

public class Main {
    public static void main(String[] args) {
        /*
        String testStr = "tes";
        int stateAutomat = 0;
        stateAutomat = TestAutomat.Automat(testStr);
        System.out.println("Proccessing result for string " + testStr + " is " + stateAutomat);
        */

        String testStr = "Test";
        TestAutomat.State stateAutomat = TestAutomat.Automat(testStr);
        System.out.println("Processing result for string \"" + testStr + "\" is " + stateAutomat);


    }
}

