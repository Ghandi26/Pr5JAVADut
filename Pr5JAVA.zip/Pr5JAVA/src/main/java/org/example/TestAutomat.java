package org.example;

public class TestAutomat {

    public enum State {
        State0, State1, State2, State3, F;
    }

    public static State Automat(String S) {
        State state = State.State0;

        for (char ch : S.toUpperCase().toCharArray()) {
            switch (state) {
                case State0:
                    state = (ch == 'T') ? State.State1 : State.State0;
                    break;
                case State1:
                    state = (ch == 'E') ? State.State2 : (ch == 'T' ? State.State1 : State.State0);
                    break;
                case State2:
                    state = (ch == 'S') ? State.State3 : (ch == 'T' ? State.State1 : State.State0);
                    break;
                case State3:
                    state = (ch == 'T') ? State.F : State.State0;
                    break;
                //case F:
                    //return state;
            }
        }

        return state;
    }
}




